package com.wfc.model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Person {

  private String personId;
  private String personName;
  private String fatherName;
  private String dateOfBirth;
  private String mobile;
  private String communicationAddress;
  private String permanentAddress;

}
