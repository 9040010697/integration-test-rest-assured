package com.wfc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootLuncher {
    public static void main(String[] args) {
        SpringApplication.run(BootLuncher.class, args);
    }


}
