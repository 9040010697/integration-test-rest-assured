package com.wfc;

import com.wfc.model.Person;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import java.util.Date;
import java.util.Random;
import java.util.UUID;

@SpringBootTest
@ActiveProfiles("dev")
public class PersonTest {

    @Value("${api.person.url}")
    private String personServiceUrl;

    @Value("${api.auth.url}")
    private String baseUriAuth;

    @Test
    void testPersonSearchWIthValidInput() {
        String token = RestAssured.given()
                .baseUri(baseUriAuth)
                .headers("x-auth-role", "ADMIN")
                .headers("x-auth-user", "ADMIN")
                .when()
                .get("/token/generate")
                .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .log()
                .ifError()
                .contentType(ContentType.TEXT)
                .extract().body().asString();

        Person person = getRandomPerson();

        RestAssured.given()
                .baseUri(personServiceUrl)
                .headers(HttpHeaders.AUTHORIZATION, token)
                .contentType(MediaType.APPLICATION_JSON_VALUE)
                .body(person)
                .when()
                .post("/person/add")
                .then()
                .assertThat()
                .log()
                .ifError()
                .statusCode(HttpStatus.OK.value());


        RestAssured.given()
                .baseUri(personServiceUrl)
                .headers(HttpHeaders.AUTHORIZATION, token)
                .headers("mobile", person.getMobile())
                .headers("personName", person.getPersonName())
                .when()
                .get("/person/search")
                .then()
                .assertThat()
                .log()
                .ifError()
                .statusCode(HttpStatus.OK.value());
    }

    private Person getRandomPerson() {
        return Person.builder()
                .personName("DJ-" + UUID.randomUUID())
                .communicationAddress("Bangalore")
                .dateOfBirth(new Date().toString())
                .fatherName("DC" + UUID.randomUUID())
                .mobile(String.valueOf(new Random().nextInt(999999999)))
                .permanentAddress("Rourkela")
                .build();
    }
}
