package com.wfc;

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("dev")
public class AuthTokenTest {

    @Value("${api.auth.url}")
    private String baseUriAuth;

    @Test
    void testAuthTokenWIthValidInput() {
        RestAssured.given()
                .baseUri(baseUriAuth)
                .headers("x-auth-role", "ADMIN")
                .headers("x-auth-user","ADMIN")
                .when()
                .get("/token/generate")
                .then()
                .assertThat()
                .statusCode(HttpStatus.OK.value())
                .log()
                .ifError();
    }

    @Test
    void testAuthTokenWIthInValidInput() {
        RestAssured.given()
                .baseUri(baseUriAuth)
                .headers("x-auth-role", "ADMIN")
                .headers("x-auth-user","INVALID_USER")
                .when()
                .get("/token/generate")
                .then()
                .assertThat()
                .statusCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .log()
                .ifError();
    }

}
